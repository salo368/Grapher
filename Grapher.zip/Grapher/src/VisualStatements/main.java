
package VisualStatements;

public class main {
    public static void main(String[] args) {
        Interfaz i = new Interfaz();
    }
}
